The dendritic and bone marrow single cell expression data is extracted from the big 40K single cell data, so they share the same 'sc_gene_list.txt' file.
The MESC single cell expression data is from another study, so it has a differenct 'sc_gene_list.txt' file.
